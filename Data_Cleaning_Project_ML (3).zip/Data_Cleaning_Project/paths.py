import os
from pathlib import Path
import yaml

class PathManager:
    """Manages all file paths for the data cleaning project."""
    
    def __init__(self, config_file: str = None):
        # Get the project root directory (where this file is located)
        self.project_root = Path(__file__).parent.absolute()
        
        # Load config if provided
        self.config = None
        if config_file:
            self.load_config(config_file)
        
        # Set up default directory structure
        self._setup_directories()
    
    def load_config(self, config_file: str):
        """Load configuration from YAML file."""
        config_path = self.get_config_path(config_file)
        try:
            with open(config_path, 'r') as f:
                self.config = yaml.safe_load(f)
        except FileNotFoundError:
            print(f"Warning: Config file {config_path} not found. Using defaults.")
            self.config = {}
    
    def _setup_directories(self):
        """Create necessary directories if they don't exist."""
        directories = [
            self.get_data_dir(),
            self.get_output_dir(),
            self.get_log_dir(),
            self.get_screenshots_dir()
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    # Configuration paths
    def get_config_path(self, filename: str = "config.yaml") -> Path:
        """Get path to configuration file."""
        return self.project_root / filename
    
    # Data directories
    def get_data_dir(self) -> Path:
        """Get data directory path."""
        if self.config and 'paths' in self.config and 'data_dir' in self.config['paths']:
            return self.project_root / self.config['paths']['data_dir']
        return self.project_root / "data"
    
    def get_output_dir(self) -> Path:
        """Get output directory path."""
        if self.config and 'paths' in self.config and 'output_dir' in self.config['paths']:
            return self.project_root / self.config['paths']['output_dir']
        return self.project_root / "output"
    
    def get_log_dir(self) -> Path:
        """Get log directory path."""
        if self.config and 'paths' in self.config and 'log_dir' in self.config['paths']:
            return self.project_root / self.config['paths']['log_dir']
        return self.project_root / "logs"
    
    def get_screenshots_dir(self) -> Path:
        """Get screenshots directory path."""
        return self.project_root / "screenshots"
    
    # Specific file paths
    def get_uncleaned_data_path(self) -> Path:
        """Get path to uncleaned dataset."""
        return self.get_data_dir() / "Uncleaned_DS_jobs.csv"
    
    def get_synthetic_data_path(self) -> Path:
        """Get path to synthetic dataset."""
        return self.get_data_dir() / "SyntheticData.csv"
    
    def get_cleaned_data_path(self, suffix: str = "") -> Path:
        """Get path for cleaned data output."""
        filename = f"cleaned_data{suffix}.csv"
        return self.get_output_dir() / filename
    
    def get_results_path(self, filename: str) -> Path:
        """Get path for results files."""
        return self.get_output_dir() / filename
    
    def get_log_path(self, filename: str) -> Path:
        """Get path for log files."""
        return self.get_log_dir() / filename
    
    def get_screenshot_path(self, filename: str) -> Path:
        """Get path for screenshot files."""
        return self.get_screenshots_dir() / filename
    
    # Utility methods
    def ensure_file_exists(self, file_path: Path, create_sample: bool = False) -> bool:
        """Check if file exists, optionally create sample."""
        if file_path.exists():
            return True
        
        if create_sample and file_path.name == "Uncleaned_DS_jobs.csv":
            print(f"Creating sample data file at: {file_path}")
            self._create_sample_data(file_path)
            return True
        
        return False
    
    def _create_sample_data(self, file_path: Path):
        """Create sample data if original file doesn't exist."""
        import pandas as pd
        
        # Create minimal sample data
        sample_data = {
            'index': [0, 1, 2],
            'Job Title': ['Data Scientist', 'Senior Data Scientist', 'Data Analyst'],
            'Salary Estimate': ['$100K-$150K (Glassdoor est.)', '$120K-$180K (Glassdoor est.)', '$80K-$120K (Glassdoor est.)'],
            'Job Description': ['Python SQL Machine Learning', 'Advanced Python ML Statistics', 'SQL Excel Data Analysis'],
            'Rating': [4.2, 3.8, 4.0],
            'Company Name': ['TechCorp\n4.2', 'DataInc\n3.8', 'AnalyticsPro\n4.0'],
            'Location': ['New York, NY', 'San Francisco, CA', 'Chicago, IL'],
            'Headquarters': ['New York, NY', 'San Francisco, CA', 'Chicago, IL'],
            'Size': ['1001 to 5000 employees', '501 to 1000 employees', '201 to 500 employees'],
            'Founded': [2010, 2005, 2015],
            'Type of ownership': ['Private', 'Public', 'Private'],
            'Industry': ['IT Services', 'Software', 'Consulting'],
            'Sector': ['Technology', 'Technology', 'Business Services'],
            'Revenue': ['$100 to $500 million (USD)', '$1 to $5 billion (USD)', '$50 to $100 million (USD)'],
            'Competitors': ['CompetitorA, CompetitorB', 'CompetitorC', 'CompetitorD, CompetitorE']
        }
        
        df = pd.DataFrame(sample_data)
        df.to_csv(file_path, index=False)
        print(f"Sample data created with {len(df)} rows")
    
    def get_relative_path(self, absolute_path: Path) -> str:
        """Convert absolute path to relative path from project root."""
        try:
            return str(absolute_path.relative_to(self.project_root))
        except ValueError:
            return str(absolute_path)
    
    def print_directory_structure(self):
        """Print the current directory structure."""
        print(" Project Directory Structure:")
        print(f"Project Root: {self.project_root}")
        print(f"├── Data Directory: {self.get_relative_path(self.get_data_dir())}")
        print(f"├── Output Directory: {self.get_relative_path(self.get_output_dir())}")
        print(f"├── Log Directory: {self.get_relative_path(self.get_log_dir())}")
        print(f"└── Screenshots Directory: {self.get_relative_path(self.get_screenshots_dir())}")
        
        # List existing files
        data_files = list(self.get_data_dir().glob("*.csv"))
        if data_files:
            print("\n Data Files Found:")
            for file in data_files:
                print(f"   • {file.name}")
        
        config_file = self.get_config_path()
        if config_file.exists():
            print(f"\n Config File: {config_file.name} ")
        else:
            print(f"\n Config File: {config_file.name}  (Not Found)")

# Global instance for easy access
_path_manager = None

def get_path_manager(config_file: str = "config.yaml") -> PathManager:
    """Get the global path manager instance."""
    global _path_manager
    if _path_manager is None:
        _path_manager = PathManager(config_file)
    return _path_manager

# Convenience functions for easy access
def get_data_path(filename: str = "Uncleaned_DS_jobs.csv") -> str:
    """Get path to data file as string."""
    pm = get_path_manager()
    if filename == "Uncleaned_DS_jobs.csv":
        return str(pm.get_uncleaned_data_path())
    elif filename == "SyntheticData.csv":
        return str(pm.get_synthetic_data_path())
    else:
        return str(pm.get_data_dir() / filename)

def get_config_path(filename: str = "config.yaml") -> str:
    """Get path to config file as string."""
    pm = get_path_manager()
    return str(pm.get_config_path(filename))

def get_output_path(filename: str) -> str:
    """Get path to output file as string."""
    pm = get_path_manager()
    return str(pm.get_output_dir() / filename)

def setup_project_structure():
    """Set up the complete project directory structure."""
    pm = get_path_manager()
    pm.print_directory_structure()
    
    # Check for required files
    uncleaned_path = pm.get_uncleaned_data_path()
    if not pm.ensure_file_exists(uncleaned_path, create_sample=True):
        print(f"\n Warning: Main data file not found at {uncleaned_path}")
        print("Please place your 'Uncleaned_DS_jobs.csv' file in the data directory.")
    
    return pm

if __name__ == "__main__":
    # Test the path manager
    print(" Testing Path Manager")
    print("=" * 40)
    pm = setup_project_structure()
    
    print(f"\n Key Paths:")
    print(f"Config: {get_config_path()}")
    print(f"Data: {get_data_path()}")
    print(f"Output: {get_output_path('results.csv')}")