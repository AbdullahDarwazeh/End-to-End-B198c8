import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from paths import get_data_path, get_path_manager

def main():
    """Profile the uncleaned dataset."""
    
    print(" Data Profiling Report")
    print("=" * 30)
    
    # Get path manager and data path
    pm = get_path_manager()
    data_path = get_data_path()
    
    print(f" Loading data from: {data_path}")
    
    try:
        df = pd.read_csv(data_path)
        print(f"   Dataset shape: {df.shape}")
    except FileNotFoundError:
        print(f" Data file not found: {data_path}")
        print("Please ensure 'Uncleaned_DS_jobs.csv' is in the data directory.")
        return
    
    # Examine columns, data types, and sample rows
    print(f"\n Columns and Data Types:")
    print(df.dtypes)
    
    print(f"\n Sample Rows:")
    print(df.head())
    
    # Calculate summary statistics for numerical columns
    numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
    print(f"\n Summary Statistics for Numerical Columns:")
    print(df[numerical_cols].describe())
    
    # Check for missing values
    print(f"\n Missing Values:")
    missing_info = df.isnull().sum()
    print(missing_info[missing_info > 0])
    
    # Identify inconsistent salary formats
    if 'Salary Estimate' in df.columns:
        print(f"\n Unique Salary Estimate Values (first 10):")
        unique_salaries = df['Salary Estimate'].unique()
        for i, salary in enumerate(unique_salaries[:10]):
            print(f"   {i+1}. {salary}")
    
    # Check for potential outliers in numerical columns
    print(f"\n Potential Outliers:")
    for col in numerical_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        outliers = df[(df[col] < Q1 - 1.5 * IQR) | (df[col] > Q3 + 1.5 * IQR)][col]
        print(f"   {col}: {len(outliers)} outliers")
    
    # Create visualizations
    create_visualizations(df, pm, numerical_cols)

def create_visualizations(df, path_manager, numerical_cols):
    """Create and save visualizations."""
    
    print(f"\n Creating visualizations...")
    
    # Set up plotting style
    plt.style.use('ggplot')
    
    # Ensure screenshots directory exists
    screenshots_dir = path_manager.get_screenshots_dir()
    
    # Create histograms for numerical columns
    for col in numerical_cols:
        try:
            plt.figure(figsize=(8, 6))
            sns.histplot(df[col].dropna(), kde=True)
            plt.title(f'Distribution of {col}')
            plt.xlabel(col)
            plt.ylabel('Count')
            
            # Save plot
            plot_path = path_manager.get_screenshot_path(f'{col}_histogram.png')
            plt.savefig(plot_path)
            plt.close()
            
            print(f"    Saved: {plot_path.name}")
            
        except Exception as e:
            print(f"    Error creating histogram for {col}: {e}")
    
    # Create bar plots for categorical columns
    categorical_cols = ['Industry', 'Location']
    for col in categorical_cols:
        if col in df.columns:
            try:
                plt.figure(figsize=(10, 6))
                df[col].value_counts().head(10).plot(kind='bar')
                plt.title(f'Top 10 {col} Categories')
                plt.xlabel(col)
                plt.ylabel('Count')
                plt.xticks(rotation=45)
                plt.tight_layout()
                
                # Save plot
                plot_path = path_manager.get_screenshot_path(f'{col}_barplot.png')
                plt.savefig(plot_path)
                plt.close()
                
                print(f"    Saved: {plot_path.name}")
                
            except Exception as e:
                print(f"    Error creating bar plot for {col}: {e}")
    
    print(f"\n All plots saved to: {screenshots_dir}")

if __name__ == "__main__":
    main()