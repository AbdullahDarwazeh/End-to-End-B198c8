import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
from cleaning import DataCleaner
import yaml
from paths import get_config_path, get_data_path

def main():
    """Run baseline model with minimal cleaning."""
    print(" Running Baseline Model")
    print("=" * 30)
    
    # Load config using path manager
    config_file = get_config_path()
    print(f" Loading config from: {config_file}")
    
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    
    # Load dataset using path manager
    data_file = get_data_path()
    print(f" Loading data from: {data_file}")
    
    df = pd.read_csv(data_file)
    print(f"   Dataset shape: {df.shape}")
    
    # Minimal cleaning
    cleaner = DataCleaner(config)
    
    print("\n Applying minimal cleaning...")
    df_clean = cleaner.clean_company_names(df)
    df_clean = cleaner.parse_salary(df_clean)
    
    # Select features
    feature_cols = ['Rating', 'Founded']  
    categorical_cols = ['Industry', 'Location', 'Sector', 'Type of ownership']
    
    print(f"   Original categorical columns: {len(categorical_cols)}")
    
    # Create dummy variables
    df_clean = pd.get_dummies(df_clean, columns=categorical_cols, dummy_na=False)
    
    # Add dummy column names to feature list
    dummy_cols = [col for col in df_clean.columns if col.startswith(tuple(cat + '_' for cat in categorical_cols))]
    feature_cols += dummy_cols
    
    print(f"   Features after dummy encoding: {len(feature_cols)}")
    
    # Prepare data
    X = df_clean[feature_cols].dropna()
    y = df_clean['Avg Salary'].loc[X.index]
    
    print(f"   Valid samples for training: {len(X)}")
    
    # Train and evaluate
    print("\n Training baseline model...")
    model = RandomForestRegressor(random_state=42)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Cross-validation
    mse_scores = -cross_val_score(model, X_scaled, y, cv=5, scoring='neg_mean_squared_error')
    mse = mse_scores.mean()
    
    print("\n BASELINE RESULTS:")
    print(f"   MSE: {mse:,.0f}")
    print(f"   RMSE: ${np.sqrt(mse):,.0f}")
    print(f"   Samples Used: {len(X):,}")
    print(f"   Features: {len(feature_cols)}")
    print(f"   CV Std: {mse_scores.std():,.0f}")
    
    return {
        'mse': mse,
        'rmse': np.sqrt(mse),
        'n_samples': len(X),
        'n_features': len(feature_cols),
        'cv_scores': mse_scores.tolist()
    }

if __name__ == "__main__":
    try:
        result = main()
        print(f"\n Baseline complete! MSE: {result['mse']:,.0f}")
    except FileNotFoundError as e:
        print(f"\n Error: {e}")
        print("Make sure your data files are in the correct location.")
        
        # Show directory structure
        from paths import setup_project_structure
        setup_project_structure()
    except Exception as e:
        print(f"\n Unexpected error: {e}")