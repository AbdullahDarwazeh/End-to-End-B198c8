import pandas as pd
import numpy as np
import random
from paths import get_path_manager, get_data_path

def generate_synthetic_data(n_rows=1000):
    """Generate synthetic dataset mimicking DataScienceJobPostings.csv with noise.
    
    Args:
        n_rows (int): Number of rows to generate. Default is 1000.
    """
    np.random.seed(42)
    random.seed(42)
    
    print(f" Generating synthetic data with {n_rows} rows...")
    
    # Define columns
    columns = ['index', 'Job Title', 'Salary Estimate', 'Job Description', 'Rating',
               'Company Name', 'Location', 'Headquarters', 'Size', 'Founded',
               'Type of ownership', 'Industry', 'Sector', 'Revenue', 'Competitors']
    
    # Generate synthetic data
    data = {
        'index': range(n_rows),
        'Job Title': [random.choice(['Data Scientist', 'Senior Data Scientist', 'Data Analyst', 'Machine Learning Engineer']) for _ in range(n_rows)],
        'Salary Estimate': [f"${random.randint(50, 150)}K-${random.randint(151, 300)}K (Glassdoor est.)" 
                           if random.random() > 0.1 else random.choice(['Unknown', '-1']) for _ in range(n_rows)],
        'Job Description': [' '.join(random.choices(['Python', 'SQL', 'Machine Learning', 'data analysis', 'statistics'], k=10)) for _ in range(n_rows)],
        'Rating': [round(random.uniform(1.0, 5.0), 1) if random.random() > 0.2 else -1.0 for _ in range(n_rows)],
        'Company Name': [f"Company_{i}" for i in range(n_rows)],
        'Location': [random.choice(['New York, NY', 'San Francisco, CA', 'Chicago, IL', 'Washington, DC', 'Other']) for _ in range(n_rows)],
        'Headquarters': [random.choice(['New York, NY', 'San Francisco, CA', 'Chicago, IL', 'Other']) for _ in range(n_rows)],
        'Size': [random.choice(['1-50 employees', '51-200 employees', '201-500 employees', '1000+ employees']) for _ in range(n_rows)],
        'Founded': [random.randint(1800, 2023) if random.random() > 0.15 else -1 for _ in range(n_rows)],
        'Type of ownership': [random.choice(['Private', 'Public', 'Non-profit', 'Other']) for _ in range(n_rows)],
        'Industry': [random.choice(['IT Services', 'Biotech', 'Finance', 'Healthcare', 'Other']) for _ in range(n_rows)],
        'Sector': [random.choice(['Technology', 'Healthcare', 'Finance', 'Business Services', 'Other']) for _ in range(n_rows)],
        'Revenue': [random.choice(['$1M-$10M', '$10M-$100M', '$100M-$1B', 'Unknown']) for _ in range(n_rows)],
        'Competitors': [random.choice(['Company A, Company B', 'None', 'Unknown', '-1']) for _ in range(n_rows)]
    }
    
    df = pd.DataFrame(data)
    
    # Get output path using path manager
    pm = get_path_manager()
    output_path = pm.get_synthetic_data_path()
    
    # Save to CSV
    df.to_csv(output_path, index=False)
    
    print(f" Generated synthetic dataset with {n_rows} rows")
    print(f" Saved to: {output_path}")
    print(f" Shape: {df.shape}")
    
    return df

def main():
    """Main function to generate synthetic data."""
    
    print(" Synthetic Data Generator")
    print("=" * 30)
    
    # Set up project structure
    from paths import setup_project_structure
    pm = setup_project_structure()
    
    # Generate synthetic data
    df = generate_synthetic_data(1000)
    
    # Show sample of generated data
    print(f"\n Sample of Generated Data:")
    print(df.head())
    
    print(f"\n Data Types:")
    print(df.dtypes)
    
    return df

if __name__ == "__main__":
    main()