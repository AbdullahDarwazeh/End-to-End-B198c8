import pandas as pd
import re
import numpy as np
from typing import List, Dict, Any
import logging

class DataCleaner:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)

    def clean_company_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean company names that have embedded ratings like 'Healthfirst\\n3.1'."""
        df = df.copy()
        
        def extract_clean_name_and_rating(row):
            company_name = str(row['Company Name'])
            current_rating = row['Rating']
            
            # Check if company name has embedded rating (contains newline)
            if '\n' in company_name:
                parts = company_name.split('\n')
                clean_name = parts[0].strip()
                
                # If current rating is invalid (-1 or NaN), try to extract from company name
                if pd.isna(current_rating) or current_rating == -1:
                    try:
                        embedded_rating = float(parts[1].strip())
                        return clean_name, embedded_rating
                    except (ValueError, IndexError):
                        return clean_name, current_rating
                else:
                    return clean_name, current_rating
            else:
                return company_name, current_rating
        
        # Apply cleaning
        df[['Company Name', 'Rating']] = df.apply(
            lambda row: pd.Series(extract_clean_name_and_rating(row)), axis=1
        )
        
        self.logger.info("Cleaned company names and extracted embedded ratings")
        return df

    def parse_salary(self, df: pd.DataFrame) -> pd.DataFrame:
        """Parse Salary Estimate into Avg Salary."""
        target_col = self.config['cleaning']['salary_parsing']['target_column']
        output_col = self.config['cleaning']['salary_parsing']['output_column']
    
        def parse_salary_string(salary: str) -> float:
            if pd.isna(salary) or salary in ['-1', 'Unknown', 'Unknown / Non-Applicable']:
                return np.nan
            
            # Handle string conversion
            salary_str = str(salary)
            
            # Match salary range patterns like "$137K-$171K (Glassdoor est.)"
            match = re.match(r'\$(\d+)K(?:-\$(\d+)K)?', salary_str)
            if match:
                low, high = match.groups()
                low = int(low)
                if high:  # Range format
                    return (low + int(high)) * 1000 / 2
                return low * 1000  # Single value
            return np.nan

        df = df.copy()
        df[output_col] = df[target_col].apply(parse_salary_string)
        
        # Impute NaN with median
        valid_salaries = df[output_col][df[output_col].notna()]
        if len(valid_salaries) > 0:
            median_salary = valid_salaries.median()
            df[output_col] = df[output_col].fillna(median_salary)
            self.logger.info(f"Parsed salaries and imputed {df[output_col].isna().sum()} missing values with median: ${median_salary:,.0f}")
        
        return df

    def impute_missing(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing values based on config."""
        df = df.copy()
        
        for col, settings in self.config['cleaning']['missing_values'].items():
            if col in df.columns:
                original_missing = (df[col] == -1).sum() + df[col].isna().sum()
                
                if settings['method'] == 'mean':
                    valid_data = df[col][(df[col] != -1) & df[col].notna()]
                    if len(valid_data) > 0:
                        mean_val = valid_data.mean()
                        df[col] = df[col].replace(-1, mean_val).fillna(mean_val)
                        
                elif settings['method'] == 'median':
                    valid_data = df[col][(df[col] != -1) & df[col].notna()]
                    if len(valid_data) > 0:
                        median_val = valid_data.median()
                        df[col] = df[col].replace(-1, median_val).fillna(median_val)
                        
                elif settings['method'] == 'mode':
                    valid_data = df[col][(df[col] != -1) & df[col].notna()]
                    if len(valid_data) > 0:
                        mode_val = valid_data.mode()[0] if len(valid_data.mode()) > 0 else valid_data.iloc[0]
                        df[col] = df[col].replace(-1, mode_val).fillna(mode_val)
                        
                elif settings['method'] == 'replace':
                    df[col] = df[col].replace(['-1', 'Unknown / Non-Applicable', -1], settings['value'])
                    df[col] = df[col].fillna(settings['value'])
                    
                elif settings['method'] == 'drop':
                    df = df[(df[col] != -1) & df[col].notna()]
                
                final_missing = (df[col] == -1).sum() + df[col].isna().sum()
                self.logger.info(f"Column {col}: {original_missing} -> {final_missing} missing values")
                
        return df

    def normalize_text(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize text columns."""
        df = df.copy()
        
        for col in self.config['cleaning']['text_normalization']['columns']:
            if col in df.columns:
                if self.config['cleaning']['text_normalization']['lowercase']:
                    df[col] = df[col].astype(str).str.lower()
                if self.config['cleaning']['text_normalization']['remove_special_chars']:
                    df[col] = df[col].str.replace(r'[^a-z0-9\s]', '', regex=True)
                    
        return df

    def handle_outliers(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle outliers in numerical columns."""
        df = df.copy()
        config = self.config['cleaning']['outlier_handling']
        method = config.get('method', 'cap')
        columns = config.get('columns', [])
    
        for col in columns:
            if col in df.columns:
                original_count = len(df)
                
                if method == 'cap':
                    Q1 = df[col].quantile(0.25)
                    Q3 = df[col].quantile(0.75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - 3 * IQR  # Softer cap (3x IQR)
                    upper_bound = Q3 + 3 * IQR
                    
                    outliers_low = (df[col] < lower_bound).sum()
                    outliers_high = (df[col] > upper_bound).sum()
                    
                    df[col] = df[col].clip(lower=lower_bound, upper=upper_bound)
                    self.logger.info(f"Capped {outliers_low + outliers_high} outliers in {col}")
                    
                elif method == 'remove':
                    Q1 = df[col].quantile(0.25)
                    Q3 = df[col].quantile(0.75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - 1.5 * IQR
                    upper_bound = Q3 + 1.5 * IQR
                    df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
                    self.logger.info(f"Removed {original_count - len(df)} outlier rows in {col}")
                    
        return df

    def extract_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract features like skills from Job Description."""
        df = df.copy()
        
        if 'Job Description' not in df.columns:
            self.logger.warning("Job Description column not found for feature extraction")
            return df
            
        skills = self.config['cleaning']['feature_engineering']['skills']
        for skill in skills:
            skill_col = f'skill_{skill.lower().replace(" ", "_")}'
            df[skill_col] = df['Job Description'].astype(str).str.contains(
                skill, case=False, na=False
            ).astype(int)
            
        self.logger.info(f"Extracted {len(skills)} skill features")
        return df
    
    def encode_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply categorical encoding with rare category grouping."""
        df = df.copy()
        
        for col in self.config['cleaning']['categorical_encoding']['columns']:
            if col in df.columns:
                # Group rare categories (less than 2% of rows)
                threshold = 0.02 * len(df)
                value_counts = df[col].value_counts()
                top_categories = value_counts[value_counts >= threshold].index[:10]  # Limit to top 10
                
                # Replace rare categories with 'Other'
                df[col] = df[col].apply(lambda x: x if x in top_categories else 'Other')
            
                if self.config['cleaning']['categorical_encoding']['method'] == 'one-hot':
                    # Get dummies and add prefix
                    dummies = pd.get_dummies(df[col], prefix=col, dummy_na=False)
                    
                    # Drop original column and add dummy columns
                    df = df.drop(columns=[col])
                    df = pd.concat([df, dummies], axis=1)
                    
                    self.logger.info(f"One-hot encoded {col} into {len(dummies.columns)} columns")
                    
                elif self.config['cleaning']['categorical_encoding']['method'] == 'label':
                    df[col] = df[col].astype('category').cat.codes
                    self.logger.info(f"Label encoded {col}")
                    
        return df
    
    def validate_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Validate the cleaned data quality."""
        validation_report = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_values': df.isna().sum().sum(),
            'duplicate_rows': df.duplicated().sum(),
            'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024**2
        }
        
        # Check for any remaining invalid values
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            infinite_vals = np.isinf(df[col]).sum() if len(df[col]) > 0 else 0
            if infinite_vals > 0:
                validation_report[f'{col}_infinite_values'] = infinite_vals
                
        return validation_report