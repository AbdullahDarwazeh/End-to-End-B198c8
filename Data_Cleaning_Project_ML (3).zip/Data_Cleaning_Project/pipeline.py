from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
from cleaning import DataCleaner
import yaml
from typing import List, Dict
import logging

class PipelineSelector:
    """Selector for evaluating and applying data cleaning pipelines."""
    
    def __init__(self, config_path: str):
        """Initialize with configuration file.
        
        Args:
            config_path (str): Path to YAML configuration file.
        """
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        self.cleaner = DataCleaner(self.config)
        self.model = RandomForestRegressor(n_estimators=100, max_depth=None, random_state=42)
        
        # Set up logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)

    def evaluate_pipeline(self, df: pd.DataFrame, cleaning_combinations: List[Dict]) -> Dict:
        """Test cleaning combinations and return best MSE.
        
        Args:
            df (pd.DataFrame): Input DataFrame.
            cleaning_combinations (List[Dict]): List of cleaning configurations.
            
        Returns:
            Dict: Best configuration, MSE, RMSE, sample count, and parameters.
        """
        results = []
        
        self.logger.info(f"Evaluating {len(cleaning_combinations)} cleaning combinations")
        
        for i, combo in enumerate(cleaning_combinations):
            self.logger.info(f"Testing combination {i+1}/{len(cleaning_combinations)}")
            
            df_clean = df.copy()
            temp_config = self.config.copy()
            
            try:
                # Update config with current combination
                for key, value in combo.items():
                    temp_config['cleaning'][key] = value
                self.cleaner.config = temp_config

                # Apply cleaning steps
                df_clean = self.cleaner.clean_company_names(df_clean)
                df_clean = self.cleaner.parse_salary(df_clean)
                df_clean = self.cleaner.impute_missing(df_clean)
                df_clean = self.cleaner.normalize_text(df_clean)
                df_clean = self.cleaner.handle_outliers(df_clean)
                df_clean = self.cleaner.extract_features(df_clean)
                df_clean = self.cleaner.encode_categorical(df_clean)
                
                # Prepare features for ML
                feature_cols = ['Rating', 'Founded']
                
                # Add skill features
                skill_cols = [f'skill_{skill.lower().replace(" ", "_")}' 
                             for skill in self.config['cleaning']['feature_engineering']['skills']]
                feature_cols.extend(skill_cols)
                
                # Add dummy variable columns
                dummy_cols = [col for col in df_clean.columns if col.startswith(('Industry_', 'Location_', 'Sector_', 'Type of ownership_'))]
                feature_cols.extend(dummy_cols)
                
                # Select only available features
                available_features = [col for col in feature_cols if col in df_clean.columns]
                
                # Prepare data for ML
                X = df_clean[available_features].dropna()
                
                # Ensure target exists
                if 'Avg Salary' not in df_clean.columns:
                    self.logger.warning(f"No Avg Salary column found for combination {i+1}")
                    continue
                    
                y = df_clean['Avg Salary'].loc[X.index]
                
                # Remove any remaining NaN values in target
                valid_idx = y.notna()
                X = X[valid_idx]
                y = y[valid_idx]
                
                if len(X) > 10:  # Minimum samples required
                    # Scale features
                    scaler = StandardScaler()
                    
                    # Use proper cross-validation with KFold
                    cv = KFold(n_splits=5, shuffle=True, random_state=42)
                    
                    # Create a pipeline for proper cross-validation
                    from sklearn.pipeline import Pipeline
                    pipeline = Pipeline([
                        ('scaler', StandardScaler()),
                        ('model', RandomForestRegressor(n_estimators=100, max_depth=None, random_state=42))
                    ])
                    
                    # Perform cross-validation
                    scores = cross_val_score(pipeline, X, y, cv=cv, scoring='neg_mean_squared_error')
                    mse = -scores.mean()
                    mse_std = scores.std()
                    
                    self.logger.info(f"Combination {i+1}: MSE = {mse:,.0f}, Samples = {len(X)}")
                    
                    results.append({
                        'config': combo,
                        'mse': mse,
                        'mse_std': mse_std,
                        'rmse': np.sqrt(mse),
                        'n_samples': len(X),
                        'n_features': len(available_features),
                        'best_params': {'n_estimators': 100, 'max_depth': None}
                    })
                else:
                    self.logger.warning(f"Insufficient samples ({len(X)}) for combination {i+1}")
                    
            except Exception as e:
                self.logger.error(f"Error in combination {i+1}: {str(e)}")
                continue
        
        # Return best configuration
        if results:
            best_result = min(results, key=lambda x: x['mse'])
            self.logger.info(f"Best MSE: {best_result['mse']:,.0f} with {best_result['n_samples']} samples")
            return best_result
        else:
            self.logger.error("No valid results found")
            return {}

    def run_best_pipeline(self, df: pd.DataFrame, best_config: Dict) -> pd.DataFrame:
        """Apply best cleaning pipeline and train final model.
        
        Args:
            df (pd.DataFrame): Input DataFrame.
            best_config (Dict): Best cleaning configuration.
            
        Returns:
            pd.DataFrame: Cleaned DataFrame.
        """
        try:
            # Update cleaner config with best configuration
            temp_config = self.config.copy()
            temp_config['cleaning'].update(best_config['config'])
            self.cleaner.config = temp_config
            
            # Apply all cleaning steps
            df_clean = df.copy()
            df_clean = self.cleaner.clean_company_names(df_clean)
            df_clean = self.cleaner.parse_salary(df_clean)
            df_clean = self.cleaner.impute_missing(df_clean)
            df_clean = self.cleaner.normalize_text(df_clean)
            df_clean = self.cleaner.handle_outliers(df_clean)
            df_clean = self.cleaner.extract_features(df_clean)
            df_clean = self.cleaner.encode_categorical(df_clean)
            
            # Train final model if we have features
            feature_cols = ['Rating', 'Founded']
            skill_cols = [f'skill_{skill.lower().replace(" ", "_")}' 
                         for skill in self.config['cleaning']['feature_engineering']['skills']]
            feature_cols.extend(skill_cols)
            dummy_cols = [col for col in df_clean.columns if col.startswith(('Industry_', 'Location_', 'Sector_', 'Type of ownership_'))]
            feature_cols.extend(dummy_cols)
            
            available_features = [col for col in feature_cols if col in df_clean.columns]
            
            if available_features and 'Avg Salary' in df_clean.columns:
                X = df_clean[available_features].dropna()
                y = df_clean['Avg Salary'].loc[X.index]
                
                # Remove NaN from target
                valid_idx = y.notna()
                X = X[valid_idx]
                y = y[valid_idx]
                
                if len(X) > 0:
                    # Train final model
                    scaler = StandardScaler()
                    X_scaled = scaler.fit_transform(X)
                    
                    final_model = RandomForestRegressor(
                        n_estimators=best_config['best_params']['n_estimators'],
                        max_depth=best_config['best_params']['max_depth'],
                        random_state=42
                    )
                    final_model.fit(X_scaled, y)
                    
                    # Feature importance
                    importance = pd.DataFrame({
                        'feature': available_features,
                        'importance': final_model.feature_importances_
                    }).sort_values('importance', ascending=False)
                    
                    self.logger.info("Feature Importance (Top 10):")
                    for idx, row in importance.head(10).iterrows():
                        self.logger.info(f"  {row['feature']}: {row['importance']:.4f}")
            
            self.logger.info(f"Applied best pipeline. Final data shape: {df_clean.shape}")
            return df_clean
            
        except Exception as e:
            self.logger.error(f"Error applying best config: {str(e)}")
            return df