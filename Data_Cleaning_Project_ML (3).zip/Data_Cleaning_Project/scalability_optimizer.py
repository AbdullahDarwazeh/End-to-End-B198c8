import pandas as pd
import numpy as np
import time
import psutil
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Dict, List, Tuple, Any
import logging
from dataclasses import dataclass
from functools import lru_cache
import pickle
import hashlib
from paths import get_config_path, get_data_path, get_output_path

@dataclass
class PerformanceMetrics:
    """Performance metrics for cleaning operations."""
    execution_time: float
    memory_usage_mb: float
    cpu_usage_percent: float
    data_reduction_ratio: float
    quality_score: float

class ScalabilityOptimizer:
    """Optimizer for scalable and efficient data cleaning."""
    
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = get_config_path()
        self.config_path = config_path
        
        # Set up logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        
        self.cache = {}
        self.performance_history = []
        
    def estimate_processing_requirements(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Estimate memory and time requirements for processing."""
        
        # Calculate dataset characteristics
        n_rows, n_cols = df.shape
        memory_usage_mb = df.memory_usage(deep=True).sum() / 1024**2
        
        # Estimate categorical explosion
        categorical_cols = df.select_dtypes(include=['object']).columns
        estimated_dummy_cols = sum(df[col].nunique() for col in categorical_cols if col in df.columns)
        
        # Estimate final memory usage
        estimated_final_memory = memory_usage_mb * (1 + estimated_dummy_cols / n_cols)
        
        # Estimate processing time based on dataset size
        estimated_time_seconds = (n_rows * n_cols) / 50000  # Empirical estimate
        
        # Recommend processing strategy
        if n_rows > 100000 or estimated_final_memory > 1000:
            strategy = "chunked_processing"
        elif n_rows > 10000:
            strategy = "parallel_processing"
        else:
            strategy = "standard_processing"
        
        return {
            'dataset_size': {'rows': n_rows, 'cols': n_cols},
            'current_memory_mb': memory_usage_mb,
            'estimated_final_memory_mb': estimated_final_memory,
            'estimated_dummy_columns': estimated_dummy_cols,
            'estimated_processing_time_seconds': estimated_time_seconds,
            'recommended_strategy': strategy,
            'chunk_size': min(10000, max(1000, n_rows // 10)) if strategy == "chunked_processing" else None
        }
    
    def chunked_processing(self, df: pd.DataFrame, cleaning_config: Dict, 
                          chunk_size: int = 10000) -> pd.DataFrame:
        """Process large datasets in chunks to manage memory."""
        
        self.logger.info(f"Processing {len(df)} rows in chunks of {chunk_size}")
        
        # Split dataframe into chunks
        chunks = [df[i:i + chunk_size] for i in range(0, len(df), chunk_size)]
        processed_chunks = []
        
        # Process each chunk
        for i, chunk in enumerate(chunks):
            self.logger.info(f"Processing chunk {i+1}/{len(chunks)}")
            
            # Apply cleaning to chunk
            from cleaning import DataCleaner
            cleaner = DataCleaner(cleaning_config)
            
            chunk_clean = chunk.copy()
            chunk_clean = cleaner.clean_company_names(chunk_clean)
            chunk_clean = cleaner.parse_salary(chunk_clean)
            chunk_clean = cleaner.impute_missing(chunk_clean)
            chunk_clean = cleaner.normalize_text(chunk_clean)
            chunk_clean = cleaner.handle_outliers(chunk_clean)
            chunk_clean = cleaner.extract_features(chunk_clean)
            
            processed_chunks.append(chunk_clean)
        
        # Combine chunks
        result = pd.concat(processed_chunks, ignore_index=True)
        
        # Apply categorical encoding to full dataset for consistency
        from cleaning import DataCleaner
        cleaner = DataCleaner(cleaning_config)
        result = cleaner.encode_categorical(result)
        
        self.logger.info(f"Chunked processing complete: {len(result)} rows")
        return result
    
    def parallel_cleaning_evaluation(self, df: pd.DataFrame, 
                                   cleaning_combinations: List[Dict],
                                   n_workers: int = None) -> List[Dict]:
        """Evaluate multiple cleaning pipelines in parallel."""
        
        if n_workers is None:
            n_workers = min(len(cleaning_combinations), mp.cpu_count() - 1)
        
        self.logger.info(f"Evaluating {len(cleaning_combinations)} pipelines with {n_workers} workers")
        
        # For simplicity, we'll run sequentially since multiprocessing requires careful setup
        # In a production environment, you'd implement proper multiprocessing
        results = []
        
        for i, cleaning_config in enumerate(cleaning_combinations):
            self.logger.info(f"Evaluating pipeline {i+1}/{len(cleaning_combinations)}")
            
            try:
                # Evaluate pipeline
                from advanced_pipeline_selector import AdvancedPipelineSelector
                selector = AdvancedPipelineSelector(self.config_path)
                result = selector.evaluate_pipeline_performance(df, cleaning_config)
                results.append(result)
                
            except Exception as e:
                self.logger.error(f"Pipeline evaluation failed: {str(e)}")
                results.append({'error': str(e), 'config': cleaning_config})
        
        return results
    
    def optimize_categorical_encoding(self, df: pd.DataFrame, 
                                    categorical_cols: List[str],
                                    max_categories_per_col: int = 10) -> pd.DataFrame:
        """Optimize categorical encoding to prevent feature explosion."""
        
        df_optimized = df.copy()
        encoding_stats = {}
        
        for col in categorical_cols:
            if col in df_optimized.columns:
                original_unique = df_optimized[col].nunique()
                
                # Group rare categories
                value_counts = df_optimized[col].value_counts()
                threshold = len(df_optimized) * 0.01  # 1% threshold
                
                top_categories = value_counts[value_counts >= threshold].head(max_categories_per_col).index
                df_optimized[col] = df_optimized[col].apply(
                    lambda x: x if x in top_categories else 'Other'
                )
                
                final_unique = df_optimized[col].nunique()
                encoding_stats[col] = {
                    'original_categories': original_unique,
                    'final_categories': final_unique,
                    'reduction_ratio': (original_unique - final_unique) / original_unique if original_unique > 0 else 0
                }
        
        self.logger.info(f"Categorical optimization: {encoding_stats}")
        return df_optimized
    
    def monitor_performance(self, operation_name: str):
        """Context manager for monitoring performance of cleaning operations."""
        
        class PerformanceMonitor:
            def __init__(self, optimizer, operation_name):
                self.optimizer = optimizer
                self.operation_name = operation_name
                self.start_time = None
                self.start_memory = None
                self.start_cpu = None
            
            def __enter__(self):
                self.start_time = time.time()
                self.start_memory = psutil.Process().memory_info().rss / 1024**2
                self.start_cpu = psutil.cpu_percent()
                return self
            
            def __exit__(self, exc_type, exc_val, exc_tb):
                end_time = time.time()
                end_memory = psutil.Process().memory_info().rss / 1024**2
                
                metrics = PerformanceMetrics(
                    execution_time=end_time - self.start_time,
                    memory_usage_mb=end_memory - self.start_memory,
                    cpu_usage_percent=psutil.cpu_percent() - self.start_cpu,
                    data_reduction_ratio=0.0,  
                    quality_score=0.0  
                )
                
                self.optimizer.performance_history.append({
                    'operation': self.operation_name,
                    'metrics': metrics,
                    'timestamp': end_time
                })
                
                self.optimizer.logger.info(
                    f"{self.operation_name}: {metrics.execution_time:.2f}s, "
                    f"{metrics.memory_usage_mb:.1f}MB, {metrics.cpu_usage_percent:.1f}% CPU"
                )
        
        return PerformanceMonitor(self, operation_name)
    
    def adaptive_chunk_sizing(self, df: pd.DataFrame, available_memory_mb: float = None) -> int:
        """Adaptively determine optimal chunk size based on available memory."""
        
        if available_memory_mb is None:
            available_memory_mb = psutil.virtual_memory().available / 1024**2
        
        # Estimate memory per row
        sample_size = min(1000, len(df))
        sample_memory = df.head(sample_size).memory_usage(deep=True).sum() / 1024**2
        memory_per_row = sample_memory / sample_size if sample_size > 0 else 1
        
        # Calculate safe chunk size (use 50% of available memory)
        safe_memory = available_memory_mb * 0.5
        optimal_chunk_size = int(safe_memory / memory_per_row) if memory_per_row > 0 else 1000
        
        # Ensure reasonable bounds
        chunk_size = max(1000, min(optimal_chunk_size, 50000))
        
        self.logger.info(f"Adaptive chunk size: {chunk_size} rows (estimated {memory_per_row:.2f}MB per row)")
        return chunk_size
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report."""
        
        if not self.performance_history:
            return {"message": "No performance data available"}
        
        # Aggregate performance metrics
        total_time = sum(p['metrics'].execution_time for p in self.performance_history)
        total_memory = sum(p['metrics'].memory_usage_mb for p in self.performance_history)
        avg_cpu = np.mean([p['metrics'].cpu_usage_percent for p in self.performance_history])
        
        # Find bottlenecks
        slowest_operation = max(self.performance_history, key=lambda x: x['metrics'].execution_time)
        memory_intensive = max(self.performance_history, key=lambda x: x['metrics'].memory_usage_mb)
        
        return {
            'summary': {
                'total_operations': len(self.performance_history),
                'total_execution_time': total_time,
                'total_memory_usage_mb': total_memory,
                'average_cpu_usage': avg_cpu
            },
            'bottlenecks': {
                'slowest_operation': {
                    'name': slowest_operation['operation'],
                    'time': slowest_operation['metrics'].execution_time
                },
                'memory_intensive_operation': {
                    'name': memory_intensive['operation'],
                    'memory_mb': memory_intensive['metrics'].memory_usage_mb
                }
            },
            'recommendations': self._generate_optimization_recommendations()
        }
    
    def _generate_optimization_recommendations(self) -> List[str]:
        """Generate optimization recommendations based on performance history."""
        recommendations = []
        
        if not self.performance_history:
            return recommendations
        
        avg_time = np.mean([p['metrics'].execution_time for p in self.performance_history])
        avg_memory = np.mean([p['metrics'].memory_usage_mb for p in self.performance_history])
        
        if avg_time > 60:  # More than 1 minute
            recommendations.append("Consider using parallel processing for large datasets")
        
        if avg_memory > 1000:  # More than 1GB
            recommendations.append("Use chunked processing to reduce memory usage")
            
        if len(self.performance_history) > 5:
            recent_times = [p['metrics'].execution_time for p in self.performance_history[-5:]]
            if len(recent_times) > 1 and np.std(recent_times) > np.mean(recent_times) * 0.5:
                recommendations.append("Performance is inconsistent - consider caching frequently used operations")
        
        return recommendations

    def run_scalable_pipeline(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Run a complete scalable pipeline with optimization."""
        
        print(" Running Scalable Data Cleaning Pipeline")
        print("=" * 50)
        
    def run_scalable_pipeline(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Run a complete scalable pipeline with optimization."""
        
        print(" Running Scalable Data Cleaning Pipeline")
        print("=" * 50)
        
        # Estimate requirements
        with self.monitor_performance("requirement_estimation"):
            requirements = self.estimate_processing_requirements(df)
        
        print(f" Dataset Analysis:")
        print(f"   Rows: {requirements['dataset_size']['rows']:,}")
        print(f"   Columns: {requirements['dataset_size']['cols']:,}")
        print(f"   Current Memory: {requirements['current_memory_mb']:.1f} MB")
        print(f"   Estimated Final Memory: {requirements['estimated_final_memory_mb']:.1f} MB")
        print(f"   Recommended Strategy: {requirements['recommended_strategy']}")
        
        # Choose processing strategy
        strategy = requirements['recommended_strategy']
        
        if strategy == "chunked_processing":
            print(f"\n Using chunked processing...")
            chunk_size = self.adaptive_chunk_sizing(df)
            
            with self.monitor_performance("chunked_cleaning"):
                # Use basic config for chunked processing
                import yaml
                with open(self.config_path, 'r') as f:
                    config = yaml.safe_load(f)
                
                cleaned_df = self.chunked_processing(df, config, chunk_size)
                
        elif strategy == "parallel_processing":
            print(f"\n Using parallel processing...")
            
            with self.monitor_performance("parallel_cleaning"):
                from advanced_pipeline_selector import AdvancedPipelineSelector
                selector = AdvancedPipelineSelector(self.config_path)
                
                # Generate fewer combinations for parallel processing
                combinations = selector.generate_cleaning_combinations(max_combinations=10)
                best_result = selector.adaptive_pipeline_selection(df)
                cleaned_df = selector.run_best_pipeline(df, best_result)
                
        else:  # standard_processing
            print(f"\n Using standard processing...")
            
            with self.monitor_performance("standard_cleaning"):
                from advanced_pipeline_selector import AdvancedPipelineSelector
                selector = AdvancedPipelineSelector(self.config_path)
                best_result = selector.adaptive_pipeline_selection(df)
                cleaned_df = selector.run_best_pipeline(df, best_result)
        
        # Generate performance report
        performance_report = self.generate_performance_report()
        
        # Save results
        output_path = get_output_path("scalable_cleaned_data.csv")
        cleaned_df.to_csv(output_path, index=False)
        
        print(f"\n Results saved to: {output_path}")
        print(f" Final dataset shape: {cleaned_df.shape}")
        
        return {
            'cleaned_data': cleaned_df,
            'requirements': requirements,
            'performance_report': performance_report,
            'strategy_used': strategy
        }

# Usage Example
def demonstrate_scalability_optimization():
    """Demonstrate the scalability optimization features."""
    
    print(" Scalability Optimization Demonstration")
    print("=" * 45)
    
    # Initialize optimizer
    optimizer = ScalabilityOptimizer()
    
    # Load data
    data_path = get_data_path()
    print(f" Loading data from: {data_path}")
    
    try:
        df = pd.read_csv(data_path)
        print(f"   Dataset loaded: {df.shape}")
    except FileNotFoundError:
        print(f" Data file not found: {data_path}")
        return
    
    # Run scalable pipeline
    results = optimizer.run_scalable_pipeline(df)
    
    # Print performance summary
    print(f"\n PERFORMANCE SUMMARY:")
    perf = results['performance_report']
    if 'summary' in perf:
        print(f"   Total Operations: {perf['summary']['total_operations']}")
        print(f"   Total Time: {perf['summary']['total_execution_time']:.2f}s")
        print(f"   Total Memory: {perf['summary']['total_memory_usage_mb']:.1f}MB")
        print(f"   Average CPU: {perf['summary']['average_cpu_usage']:.1f}%")
        
        if perf['recommendations']:
            print(f"\n Recommendations:")
            for rec in perf['recommendations']:
                print(f"   • {rec}")
    
    print(f"\n Scalability optimization complete!")
    return results

if __name__ == "__main__":
    try:
        results = demonstrate_scalability_optimization()
    except Exception as e:
        print(f"\n Error: {e}")
        import traceback
        traceback.print_exc()